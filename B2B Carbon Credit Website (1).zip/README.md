
  # B2B Carbon Credit Website

  This is a code bundle for B2B Carbon Credit Website. The original project is available at https://www.figma.com/design/MOmb1n1p2GY6hYG8kVYIAx/B2B-Carbon-Credit-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  